package com.example.myfotoseleter

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.myfotoseleter.ui.theme.MyFotoSeleterTheme
import java.io.File

class MainActivity : ComponentActivity() {

    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var files: Array<File>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Get the list of photos
        val files = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MyApp").listFiles() ?: emptyList()

        // Create an adapter for the list
        adapter = PhotoListAdapter(this, files)

        // Set the adapter on the list
        listView.adapter = adapter

        listView.setOnItemClickListener(adapter::onItemClick)
    }
        // Get the list of photos
        files = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "MyApp"
        ).listFiles()

        // Create an adapter for the list
        adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_multiple_choice,
            files.map { it.name }
        )

        // Set the adapter on the list
        findViewById<ListView>(R.id.listView).adapter = adapter
    }

    fun onItemClick(parent: AdapterView<*>, view: View, position: Int, id: Long) {
        // Obtener el nombre de la foto seleccionada
        val fileName = files[position].name

        // Marcar o desmarcar la foto
        val checked = adapter.getItem(position) as String ?: ""
        adapter.setItemChecked(position, !checked.isEmpty())
    }
}
